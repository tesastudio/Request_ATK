<div>
    <p>Hi, you have a new message from {{ $data['name'] }}.</p>
    <p>Message: {{ $data['message'] }}</p>
    <p>Thank you</p>
</div>