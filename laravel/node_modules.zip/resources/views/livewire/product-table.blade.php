<div>
    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Harga</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>baju</td>
                <td>1900</td>
                <td>
                    <button class="btn badge bg-warning">Update</button>
                    <button class="btn badge bg-danger">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
