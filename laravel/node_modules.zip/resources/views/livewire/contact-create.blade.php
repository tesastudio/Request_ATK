<div>
    @section('content')
    <div class="content-wrapper">
        <form action="">
            <div class="form-group">
                <div class="col">
                    <input type="text" name="" id="" class="form-control" placeholder="Name">
                </div>
                <div class="col">
                    <input type="text" name="" id="" class="form-control" placeholder="Name">
                </div>
            </div>
            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
        </form>
    </div>
    @endsection
</div>
