<img src="{{ asset('logo/tiara.png') }}" alt="Tiara Kencana" width="300px">
