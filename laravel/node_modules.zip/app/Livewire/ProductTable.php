<?php

namespace App\Livewire;

use Livewire\Component;

class ProductTable extends Component
{
    public function render()
    {
        return view('livewire.product-table');
    }
}
