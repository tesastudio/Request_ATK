<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test Email</title>
</head>
<body>
    <h1>Test Email</h1>
    <p>Just sending my email....</p>
</body>
</html><?php /**PATH C:\data\laravel\tina_request\resources\views/emails/template_email.blade.php ENDPATH**/ ?>