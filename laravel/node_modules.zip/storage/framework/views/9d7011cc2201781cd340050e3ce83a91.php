<img src="<?php echo e(asset('logo/tiara.png')); ?>" alt="Tiara Kencana" width="300px">
<?php /**PATH C:\data\laravel\tina_request\resources\views/components/application-logo.blade.php ENDPATH**/ ?>