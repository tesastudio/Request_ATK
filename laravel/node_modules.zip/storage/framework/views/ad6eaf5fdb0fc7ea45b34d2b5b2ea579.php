<div class="container">
    <!-- START FORM -->
    <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
        <div class="pt-3">
            <div class="alert alert-danger">
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="pt-3">
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <form>
            <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" wire:model="nama">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" wire:model="email">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" wire:model="alamat">
                </div>
            </div>
            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                    <!--[if BLOCK]><![endif]--><?php if($updateData == false): ?>
                    <button type="button" class="btn btn-primary" name="submit" wire:click="store()">SIMPAN</button>
                    <?php else: ?>
                    <button type="button" class="btn btn-primary" name="submit" wire:click="update()">UPDATE</button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <button type="button" class="btn btn-primary" name="submit" wire:click="clear()">Clear</button>
                </div>
            </div>
        </form>
    </div>
    <!-- AKHIR FORM -->

    <!-- START DATA -->
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <h1>Data Pegawai</h1>
        <div class="pb-3 pt-3">
            <input type="text" class="form-control mb-3 w-25" placeholder="Search.." wire:model.live="katakunci">
        </div>
        <!--[if BLOCK]><![endif]--><?php if($employee_selected_id): ?>
        <a wire:click="delete_confirmation('')" class="btn btn-danger btn-sm mb-3"
            data-bs-toggle="modal" data-bs-target="#exampleModal">Del <?php echo e(count($employee_selected_id)); ?> data</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <table class="table table-striped table-sortable">
            <thead>
                <tr>
                    <th></th>
                    <th class="col-md-1">No</th>
                    <th class="col-md-4 sort <?php if($sortColumn=='nama'): ?><?php echo e($sortDirection); ?>  <?php endif; ?>" wire:click="sort('nama')">Nama</th>
                    <th class="col-md-3 sort <?php if($sortColumn=='email'): ?><?php echo e($sortDirection); ?>  <?php endif; ?>" wire:click="sort('email')">Email</th>
                    <th class="col-md-2 sort <?php if($sortColumn=='alamat'): ?><?php echo e($sortDirection); ?>  <?php endif; ?>" wire:click="sort('alamat')">Alamat</th>
                    <th class="col-md-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dataEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <tr>
                    <td><input type="checkbox" wire:key="<?php echo e($value->id); ?>" value="<?php echo e($value->id); ?>" wire:model.live="employee_selected_id"></td>
                    <td><?php echo e($dataEmployees->firstItem() + $key); ?></td>
                    <td><?php echo e($value->nama); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->alamat); ?></td>
                    <td>
                        <a wire:click="edit(<?php echo e($value->id); ?>)" class="btn btn-warning btn-sm">Edit</a>
                        <a wire:click="delete_confirmation(<?php echo e($value->id); ?>)" class="btn btn-danger btn-sm"
                            data-bs-toggle="modal" data-bs-target="#exampleModal">Del</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
        <?php echo e($dataEmployees->links()); ?>

    </div>
    <!-- AKHIR DATA -->
    <div wire:ignore.self class="modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLable">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Konfirmasi Penghapusan</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Yakin ingin menghapus data ini</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
              <button type="button" class="btn btn-primary" wire:click="delete()" data-bs-dismiss="modal">Ya</button>
            </div>
          </div>
        </div>
      </div>
</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/employee.blade.php ENDPATH**/ ?>