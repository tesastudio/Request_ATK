<footer class="main-footer">
    <strong>Copyright &copy; 2014-2019 <a href="https://tiarakencana.com">Tiara Kencana</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer><?php /**PATH C:\data\laravel\tina_request\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>