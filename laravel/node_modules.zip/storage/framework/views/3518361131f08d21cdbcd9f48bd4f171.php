<div>
    
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><?php echo e($header_title); ?></h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="float-sm-left">
            
          </ol>
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard v1</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
   
    <!-- /.content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Goods List </h3>
              </div>
              <div class="row">
                <div class="col-sm-2 mt-3 ml-3">
                  <label for="" class="form-label">Filter</label>
                </div>
                <div class="col-sm-8 mt-2">
                  <input type="text" class="form-control" wire:model.live="search" placeholder="Search by name or type" >
                </div>
              </div>
              

              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Name of Goods</th>
                      <th>Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->goods_type); ?></td>
                        <td>
                          
                          <a wire:click="select(<?php echo e($item->id); ?>)" class="btn btn-warning btn-xs">Select</a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    
                  </tbody>
                </table>
                
                <div class="d-flex justify-content-right">
                  <?php echo e($goods->links('pagination::bootstrap-5')); ?>

                </div>
              </div>
              <!-- /.card-body -->
              
            </div>
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Selected Goods</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Name of Goods</th>
                      <th>Type</th>
                      <th>Qty</th>
                      <th>Unit</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $goodsreqdet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item_req->id); ?></td>
                        <td><?php echo e($item_req->name); ?></td>
                        <td><?php echo e($item_req->goods_type); ?></td>
                        <td><?php echo e($item_req->qty_req); ?></td>
                        <td><?php echo e($item_req->unit); ?></td>
                        <td>
                          <a wire:click="edit_req(<?php echo e($item_req); ?>)" class="btn btn-primary btn-xs" data-bs-toggle="modal" data-bs-target="#Modal1">Edit</a>
                          <a wire:click="unselect(<?php echo e($item_req->id); ?>)" class="btn btn-danger btn-xs">UnSelect</a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <div class="col-sm-10">
            <button type="button" class="btn btn-primary" wire:click="submit()">Process</button>
            <button type="button" class="btn btn-warning" wire:click="clearall()">Clear All</button>
            </div>
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
      
      </div><!-- /.container-fluid -->
    </section>


  </div>

  <!-- Button trigger modal -->


<!-- Modal -->
<div wire:ignore.self class="modal" id="Modal1" tabindex="-1" aria-labelledby="Modal1Label">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--[if BLOCK]><![endif]--><?php if($gr_status = 0): ?>
        <div class="modal-header">
          <h5 class="modal-title" id="Modal1">Edit Qty</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      <div class="modal-body">
        <form action="">
          <div class="mb-3">
            <label for="">Name</label>
            <input type="hidden" class="form-control" id="id" wire:model="id" disabled>
            <input type="text" class="form-control" id="name" wire:model="name" disabled>
          </div>
          <div class="mb-3">
            <label for="">Type</label>
            <input type="text" class="form-control" id="goods_type" wire:model="goods_type" disabled>
          </div>
          <div class="mb-3">
            <label for="">Qty</label>
            <input type="number" class="form-control" id="qty_req" wire:model.live="qty_req">
          </div>
          <div class="mb-3">
            <label for="">Unit</label>
            <input type="text" class="form-control" id="unit" wire:model="unit" disabled>
          </div>
          
        </form>
        <p>Anda hanya dapat merubah quantity barang </p>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
        <button type="submit" class="btn btn-primary" wire:click="upd_qty_req(<?php echo e($id); ?>, <?php echo e($qty_req); ?>)" data-bs-dismiss="modal">Ya</button>
      </div>
    </div>
  </div>
</div>



</div><?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/goodsreq/goods-request.blade.php ENDPATH**/ ?>