<div>
    
    User Test
    Ini dalam content       
    <form action="">
        <label for="">Dept</label>
        <input type="text" wire:model="dept">
        <button type="button" name="submit" class="btn btn-primary" wire:click="store()">Simpan</button>
    </form>
    
    
</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/user-test.blade.php ENDPATH**/ ?>