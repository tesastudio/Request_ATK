<div>
    
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-6">
          <div class="col-sm-6">
            <h1><?php echo e($header_title); ?></h1>
          </div>
          <div>
            <div class="col-sm-12" style="text-align: right;">
              <a href="<?php echo e(url('admin/admin/add')); ?>" class="btn btn-primary">Next</a>
            </div>

          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
   
    <!-- /.content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Request List</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Requestor</th>
                      <th>Dept</th>
                      <th>Notes</th>
                      <th>Need Date</th>
                      <th>Status</th>
                      <th>Current Resp.</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $poreq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->deptname); ?></td>
                        <td><?php echo e($item->remark); ?></td>
                        <td><?php echo e($item->need_date); ?></td>
                        <td><?php echo e($item->status_desc); ?></td>
                        <td><?php echo e($item->taskname); ?></td>
                        <td>
                          
                          <a wire:click="select(<?php echo e($item->id); ?>)" class="btn btn-warning btn-xs">Select</a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              
            </div>
            <!-- /.card -->

            <!-- /.card -->
          
          
          
        </div>
        <!-- /.row -->
        
        <!-- /.row -->
        
        <!-- /.row -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
          Launch static backdrop modal
        </button>
      </div><!-- /.container-fluid -->
    </section>


  </div>

  <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>



</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/purchase/purchase-status.blade.php ENDPATH**/ ?>