<div>
    <?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('contact-create', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-23962344-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Phone</th>
                <th scope="col">#</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0; ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $no++; ?>
        <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($contact->name); ?></td>
            <td><?php echo e($contact->phone); ?></td>
            <td>
                <button class="btn btn-sm btn-info text-white">Edit</button>
                <button class="btn btn-sm btn-danger text-white">Edit</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </tbody>
</table>
    </div>
<?php $__env->stopSection(); ?>
</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/contact-index.blade.php ENDPATH**/ ?>