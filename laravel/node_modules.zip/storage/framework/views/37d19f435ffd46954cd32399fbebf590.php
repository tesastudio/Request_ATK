<div>
    
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-6">
          <div class="col-sm-6">
            <h1><?php echo e($header_title); ?> </h1>
          </div>
          <div>
            <div class="col-sm-12" style="text-align: right;">
            </div>

          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
   
    <!-- /.content -->
    

    <section class="content">
      <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
        <div class="pt-3">
            <div class="alert alert-danger">
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        </div>
      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      <?php echo $__env->make('_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div class="my-3 p-3 bg-body rounded shadow-sm">
          <form>
              <?php echo csrf_field(); ?>
              <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">General</h3>
  
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="username" class="col-form-label">Created by</label>
                      <div>
                          <input type="hidden" class="form-control" wire:model="gr_status" value="<?php echo e($this->gr_status); ?>" >
                          <input type="text" class="form-control" wire:model="username" disabled>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="remark" class="col-form-label">Notes</label>
                      <div>
                        <textarea wire:model.live="remark" class="form-control" rows="3" disabled></textarea>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="comment" class="col-form-label">Comment</label>
                      <div>
                        <textarea wire:model="comment" class="form-control" rows="3"></textarea>
                      </div>
                    </div>
                    
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="deptname" class="col-form-label">Department</label>
                      <div>
                          <input type="text" class="form-control" wire:model="deptname" aria-readonly="true" disabled>
                      </div>
                    </div>
                    <div class="form-group">
                        <label for="need_date" class="col-form-label">Expected Date</label>
                        <div>
                            <input type="date" class="form-control" id="need_date" wire:model.live="need_date" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="doc_status" class="col-form-label">Doc Status</label>
                        <div>
                            <input type="text" class="form-control" id="doc_status" wire:model.live="doc_status" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                      <label for="lastcomment" class="col-form-label">Last Comment</label>
                      <div>
                        <textarea wire:model.live="lastcomment" class="form-control" rows="3" disabled></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="mb-3 row">
                   
                  <div class="col-sm-10">
                    
                    
                    <!--[if BLOCK]><![endif]--><?php if($goodsreq->task_userid == Auth::user()->id && $this->gr_status == 2 ): ?>
                      <button type="button" class="btn btn-primary" name="submit" wire:click="approval()">Approve . <?php echo e($nextapproval); ?></button>
                      <button type="button" class="btn btn-secondary" name="rejection" wire:click="rejection()">Reject</button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($created_id == Auth::user()->id ): ?>
                      <button type="button" class="btn btn-primary" name="submit" wire:click="send_approval()">Send for Reminder</button>
                      
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php if($goodsreq->task_userid == Auth::user()->id && $this->gr_status == 3): ?>
                      <button type="button" class="btn btn-primary" name="submit" wire:click="deliver()">Deliver</button>
                      
                      
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->gr_status == 4 && Auth::user()->id == $goodsreq->task_userid): ?>
                      <button type="button" class="btn btn-primary" name="submit" wire:click="received()">Received</button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <button type="button" class="btn btn-warning" name="submin" data-bs-toggle="modal" data-bs-target="#ModalInfo">Info</button>
                  </div>
                  Current Process: <?php echo e($this->task_username); ?><br>
                  Next Process: <?php echo e($this->nextapproval_name); ?> <?php echo e($this->nextapproval); ?>

                </div>
              </div>
              
          </form>
      </div>
      <div class="card card-secondary">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Selected Goods <?php echo e($count_item); ?></h3>
          </div>
              <!-- /.card-header -->
          <div class="card-body p-0">
            <table class="table table-striped">
              <thead>
                
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Name of Goods</th>
                  <th>Type</th>
                  <th class="text-right" >Qty Request</th>
                  <th>Unit</th>
                  <!--[if BLOCK]><![endif]--><?php if($this->gr_status == 3): ?>
                    <th class="text-right">Qty Remaind</th>
                    <!--[if BLOCK]><![endif]--><?php if(Auth::user()->dept_id == 2 ): ?>
                      <th class="text-right">Qty Avail</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <th class="text-right">Qty Delvr</th>
                    <th class="text-right">Qty Rcved</th>
                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                  <!--[if BLOCK]><![endif]--><?php if($this->gr_status >= 4): ?>
                    <th class="text-right">Qty Remaind</th>
                    <th class="text-right">Qty Delvr</th>
                    <th class="justify-content-center">Qty Received</th>
                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tr>
                
              </thead>
              <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $goodsreqdet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item_req->id); ?></td>
                    <td><?php echo e($item_req->name); ?></td>
                    <td style="width: 15px"><?php echo e($item_req->goods_type); ?></td>
                    <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_req); ?></td>
                    <td style="width: 15px"><?php echo e($item_req->unit); ?></td>
                    <!--[if BLOCK]><![endif]--><?php if($this->gr_status == 3): ?>
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_rmn); ?></td>
                        <!--[if BLOCK]><![endif]--><?php if(Auth::user()->dept_id == 2 ): ?>
                          <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_onhand); ?></td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_delvr); ?></td>
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_recvd); ?></td>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                      <!--[if BLOCK]><![endif]--><?php if($this->gr_status >= 4): ?>
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_rmn); ?></td>
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_delvr); ?></td>
                        <td class="text-right" style="width: 10px"><?php echo e($item_req->qty_recvd); ?></td>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <td>
                      <!--[if BLOCK]><![endif]--><?php if($this->gr_status <= 1 && $created_id == Auth::user()->id): ?>
                        <a wire:click="edit_req(<?php echo e($item_req); ?>)" class="btn btn-primary btn-xs" data-bs-toggle="modal" data-bs-target="#Modal1">Edit</a>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                      
                      <!--[if BLOCK]><![endif]--><?php if($this->gr_status == 3 && $goodsreq->task_userid == Auth::user()->id ): ?>
                        <a wire:click="edit_alloc(<?php echo e($item_req); ?>)" class="btn btn-primary btn-xs" data-bs-toggle="modal" data-bs-target="#Modal2">Edit</a>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                      <!--[if BLOCK]><![endif]--><?php if($this->gr_status == 4 && $goodsreq->task_userid == Auth::user()->id ): ?>
                        <a wire:click="edit_received(<?php echo e($item_req); ?>)" class="btn btn-primary btn-xs" data-bs-toggle="modal" data-bs-target="#Modal3">Edit</a>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                      
                      
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                
              </tbody>
            </table>
          </div>
        </div>
        
      </div>
      
    </section>
    <section>
      <div class="card card-primary">
        <div class="card-header">
          <h3 class="card-title">Tracing Document</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
          </div>
        </div>
        <div class="card-body">
          <ul>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tracedoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>

                <span class="text"><?php echo e($item->created_at); ?></span>
                <span class="badge badge-warning"><?php echo e($item->action); ?></span>
                <span class="text"><?php echo e($item->username); ?></span>
                <span class="text direct-chat-text"><?php echo e($item->comment); ?></span>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

          </ul>
         
        </div>
      </div>

    </section>
      
      
    </section>


  </div>

  <!-- Button trigger modal -->


  <!-- Modal -->

  <div wire:ignore.self class="modal" id="Modal1" tabindex="-1" aria-labelledby="Modal1Label">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--[if BLOCK]><![endif]--><?php if($gr_status = 0): ?>
          <div class="modal-header">
            <h5 class="modal-title" id="Modal1">Edit Qty</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="modal-body">
          <form action="">
            <div class="mb-3">
              <label for="">Name</label>
              <input type="hidden" class="form-control" id="id" wire:model="id" disabled>
              <input type="hidden" class="form-control" id="goods_id" wire:model="goods_id" disabled>
              <input type="text" class="form-control" id="name" wire:model="name" disabled>
            </div>
            <div class="mb-3">
              <label for="">Type</label>
              <input type="text" class="form-control" id="goods_type" wire:model="goods_type" disabled>
            </div>
            <div class="mb-3">
              <label for="">Qty</label>
              <input type="number" class="form-control" id="qty_req" wire:model.live="qty_req">
            </div>
            <div class="mb-3">
              <label for="">Unit</label>
              <input type="text" class="form-control" id="unit" wire:model="unit" disabled>
            </div>
            
          </form>
          <p>Anda hanya dapat merubah quantity barang </p>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
          <button type="submit" class="btn btn-primary" wire:click="upd_qty_req(<?php echo e($id); ?>, <?php echo e($goods_id); ?>, <?php echo e($qty_req); ?>)" data-bs-dismiss="modal">Ya</button>
        </div>
      </div>
    </div>
  </div>

  <div wire:ignore.self class="modal" id="Modal2" tabindex="-1" aria-labelledby="Modal2Label">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--[if BLOCK]><![endif]--><?php if($gr_status = 3): ?>
          <div class="modal-header">
            <h5 class="modal-title" id="Modal2">Edit Qty Allocation</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="modal-body">
          <form action="">
            <div class="mb-3">
              <label for="">Name</label>
              <input type="hidden" class="form-control" id="id" wire:model="id" disabled>
              <input type="text" class="form-control" id="name" wire:model="name" disabled>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="">Type</label>
                  <input type="text" class="form-control" id="goods_type" wire:model="goods_type" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Request</label>
                  <input type="number" class="form-control" id="qty_req" wire:model.live="qty_req" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Alocation</label>
                  <input type="number" class="form-control" id="qty_delvr" wire:model.live="qty_delvr">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="">Unit</label>
                  <input type="text" class="form-control" id="unit" wire:model="unit" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Available</label>
                  <input type="number" class="form-control" id="qty_onhand" wire:model.live="qty_onhand" disabled>
                </div>
                
              </div>
            </div>
            
            
          </form>
          <p>Anda hanya dapat merubah quantity Alokasi barang </p>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
          <button type="submit" class="btn btn-primary" wire:click="upd_qty_delvr(<?php echo e($id); ?>, <?php echo e($goods_id); ?>, <?php echo e($qty_delvr); ?>)" data-bs-dismiss="modal">Ya</button>
        </div>
      </div>
    </div>
  </div>

  <div wire:ignore.self class="modal" id="Modal3" tabindex="-1" aria-labelledby="Modal3Label">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--[if BLOCK]><![endif]--><?php if($gr_status = 3): ?>
          <div class="modal-header">
            <h5 class="modal-title" id="Modal3">Edit Qty Allocation</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="modal-body">
          <form action="">
            <div class="mb-3">
              <label for="">Name</label>
              <input type="hidden" class="form-control" id="id" wire:model="id" disabled>
              <input type="text" class="form-control" id="name" wire:model="name" disabled>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="">Type</label>
                  <input type="text" class="form-control" id="goods_type" wire:model="goods_type" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Request</label>
                  <input type="number" class="form-control" id="qty_req" wire:model.live="qty_req" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Received</label>
                  <input type="number" class="form-control" id="qty_recvd" wire:model.live="qty_recvd">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="">Unit</label>
                  <input type="text" class="form-control" id="unit" wire:model="unit" disabled>
                </div>
                <div class="mb-3">
                  <label for="">Qty Delivered</label>
                  <input type="number" class="form-control" id="qty_delvr" wire:model.live="qty_delvr" disabled>
                </div>
                
              </div>
            </div>
            
            
          </form>
          <p>Anda hanya dapat merubah quantity Alokasi barang </p>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
          <button type="submit" class="btn btn-primary" wire:click="upd_qty_received(<?php echo e($id); ?>, <?php echo e($goods_id); ?>, <?php echo e($qty_recvd); ?>)" data-bs-dismiss="modal">Ya</button>
        </div>
      </div>
    </div>
  </div>

  <div wire:ignore.self class="modal" id="ModalInfo" tabindex="-1" aria-labelledby="Modal2Label">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--[if BLOCK]><![endif]--><?php if($gr_status = 3): ?>
          <div class="modal-header">
            <h5 class="modal-title" id="ModalInfo">Information</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="modal-body">
          <div class="invoice p-3 mb-3">
            <!-- title row -->
            <div class="row">
              <div class="col-12">
                <h4>
                  <i class="fas fa-info"></i> Tiara Kencana
                  
                </h4>
              </div>
              <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
              <div class="col invoice-col">
                <table>
                  <colgroup>
                    <col>
                  </colgroup>
                  <tr>
                    <td>Document#</td>
                    <td><?php echo e($this->req_id); ?></td>
                  </tr>
                  <tr>
                  <tr>
                    <td>Document Date</td>
                    <td><?php echo e($this->created_date); ?></td>
                  </tr>
                  <tr>
                    <td>Created by</td>
                    <td><?php echo e($this->created_by); ?></td>
                  </tr>
                  <tr>
                    <td>Current Status</td>
                    <td><?php echo e($this->doc_status); ?></td>
                  </tr>
                  <tr>
                    <td>Current Status Resp.</td>
                    <td><?php echo e($this->task_username); ?></td>
                  </tr>
                </table>
              </div>
              <!-- /.col -->
              
              <!-- /.col -->
              
              <!-- /.col -->
            </div>
          </div>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Exit</button>
        </div>
      </div>
    </div>
  </div>



</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/goodsreq/edit-goods-request.blade.php ENDPATH**/ ?>