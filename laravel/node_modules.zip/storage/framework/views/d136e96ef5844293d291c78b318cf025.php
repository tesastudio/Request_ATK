<div>
    Rumah homepage
</div>
<?php /**PATH C:\data\laravel\tina_request\resources\views/livewire/rumah.blade.php ENDPATH**/ ?>